#include "driver/uart.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define PC_UART      UART_NUM_0
#define ANANO_UART   UART_NUM_2

#define ANANO_TX_PIN 17
#define ANANO_RX_PIN 16

#define BUFFER_SIZE 256

static void pc_to_anano_task(void *arg)
{
    uint8_t buffer[BUFFER_SIZE];

    while(1)
    {
        int len =
            uart_read_bytes(
                PC_UART,
                buffer,
                BUFFER_SIZE,
                pdMS_TO_TICKS(100));

        if(len > 0)
        {
            uart_write_bytes(
                ANANO_UART,
                (const char *)buffer,
                len);
        }
    }
}

static void anano_to_pc_task(void *arg)
{
    uint8_t buffer[BUFFER_SIZE];

    while(1)
    {
        int len =
            uart_read_bytes(
                ANANO_UART,
                buffer,
                BUFFER_SIZE,
                pdMS_TO_TICKS(100));

        if(len > 0)
        {
            uart_write_bytes(
                PC_UART,
                (const char *)buffer,
                len);
        }
    }
}

void app_main(void)
{
    uart_config_t anano_cfg =
    {
        .baud_rate = 115200,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT
    };

    uart_driver_install(
        ANANO_UART,
        2048,
        2048,
        0,
        NULL,
        0);

    uart_param_config(
        ANANO_UART,
        &anano_cfg);

    uart_set_pin(
        ANANO_UART,
        ANANO_TX_PIN,
        ANANO_RX_PIN,
        UART_PIN_NO_CHANGE,
        UART_PIN_NO_CHANGE);

    xTaskCreate(
        pc_to_anano_task,
        "pc_to_anano",
        4096,
        NULL,
        5,
        NULL);

    xTaskCreate(
        anano_to_pc_task,
        "anano_to_pc",
        4096,
        NULL,
        5,
        NULL);
}