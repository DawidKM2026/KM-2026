# Dla wielu aNano

import tkinter as tk
from tkinter import ttk
from tkinter.scrolledtext import ScrolledText

import serial
import serial.tools.list_ports
import struct

import threading

PREAMBLE = 0xAA

CMD_PING          = 0x0001
CMD_STATUS        = 0x0002

CMD_HOMING        = 0x0100
CMD_MOVE_ABS      = 0x0200
CMD_MOVE_REL      = 0x0400
CMD_STOP_MOTOR    = 0x0800

CMD_SET_SPEED     = 0x1000
CMD_SET_ACCEL     = 0x2000
CMD_MOVE_VELOCITY = 0x4000

CMD_LIVE_MPU  = 0x0004
CMD_HIST_MPU  = 0x0008

CMD_LIVE_GYRO = 0x0010
CMD_HIST_GYRO = 0x0020

CMD_PUSH_INFO = 0x0040

class UARTGui:

    def __init__(self, root):

        self.root = root
        self.root.title("Nano Motion Controller v2")
        self.root.geometry("1000x700")
        self.waiting_reply = False
        self.telemetry_enabled = False
        self.ser = None

        # LIVE MPU
        self.pitch_live_var = tk.StringVar(value="-")
        self.roll_live_var  = tk.StringVar(value="-")

        # HIST MPU
        self.pitch_peak_var = tk.StringVar(value="-")
        self.roll_peak_var  = tk.StringVar(value="-")

        # LIVE GYRO
        self.gx_live_var = tk.StringVar(value="-")
        self.gy_live_var = tk.StringVar(value="-")
        self.gz_live_var = tk.StringVar(value="-")

        # HIST GYRO
        self.gx_peak_var = tk.StringVar(value="-")
        self.gy_peak_var = tk.StringVar(value="-")
        self.gz_peak_var = tk.StringVar(value="-")

        # PUSH INFO
        self.g_peak_var = tk.StringVar(value="-")
        self.push_count_var = tk.StringVar(value="-")

        # STATUS
        self.pos_var = tk.StringVar(value="-")
        self.busy_var = tk.StringVar(value="-")

        self.build_ui()

    def build_ui(self):

        header = ttk.Frame(self.root)
        header.pack(fill="x", padx=10, pady=5)

        ttk.Label(
            header,
            text="COM"
        ).pack(side="left")

        ports = [
            p.device
            for p in serial.tools.list_ports.comports()
        ]

        self.com_var = tk.StringVar(
            value=ports[0] if ports else "COM8"
        )

        ttk.Combobox(
            header,
            textvariable=self.com_var,
            values=ports,
            width=10
        ).pack(side="left", padx=5)

        ttk.Button(
            header,
            text="Connect",
            command=self.connect
        ).pack(side="left", padx=3)

        ttk.Button(
            header,
            text="Disconnect",
            command=self.disconnect
        ).pack(side="left", padx=3)

        ttk.Button(
            header,
            text="Quit",
            command=self.quit_app
        ).pack(side="left", padx=3)

        self.status_label = tk.Label(
            header,
            text="● OFFLINE",
            fg="red"
        )

        self.status_label.pack(
            side="right",
            padx=10
        )

        target = ttk.LabelFrame(
            self.root,
            text="Target"
        )

        target.pack(
            fill="x",
            padx=10,
            pady=5
        )

        ttk.Label(
            target,
            text="Board"
        ).grid(row=0,column=0)

        self.board_var = tk.IntVar(value=2)

        ttk.Combobox(
            target,
            textvariable=self.board_var,
            values=[0,1,2,3,4,5],
            width=10
        ).grid(row=0,column=1,padx=5)

        ttk.Label(
            target,
            text="Motor"
        ).grid(row=0,column=2)

        self.motor_var = tk.IntVar(value=1)

        ttk.Combobox(
            target,
            textvariable=self.motor_var,
            values=[0,1,2,3,4,5],
            width=10
        ).grid(row=0,column=3,padx=5)

        status = ttk.LabelFrame(
            self.root,
            text="Status"
        )

        status.pack(
            fill="x",
            padx=10,
            pady=5
        )

        ttk.Label(
            status,
            text="Busy:"
        ).pack(side="left", padx=(30,0))

        ttk.Label(
            status,
            textvariable=self.busy_var
        ).pack(side="left")


        ttk.Label(
            status,
            text="Current Position:"
        ).pack(side="left")

        ttk.Label(
            status,
            textvariable=self.pos_var
        ).pack(side="left", padx=10)

        jog = ttk.LabelFrame(
            self.root,
            text="Jog Control"
        )

        jog.pack(
            fill="x",
            padx=10,
            pady=5
        )

        ttk.Button(
            jog,
            text="<<",
            command=lambda: self.move_rel(-1000)
        ).grid(row=0,column=0,padx=5,pady=5)

        ttk.Button(
            jog,
            text="<",
            command=lambda: self.move_rel(-100)
        ).grid(row=0,column=1,padx=5,pady=5)

        self.stop_button = tk.Button(
            jog,
            text="STOP",
            bg="red",
            fg="white",
            width=20,
            command=self.cmd_stop
        )

        self.stop_button.grid(
            row=0,
            column=2,
            padx=15,
            pady=5
        )

        ttk.Button(
            jog,
            text=">",
            command=lambda: self.move_rel(100)
        ).grid(row=0,column=3,padx=5,pady=5)

        ttk.Button(
            jog,
            text=">>",
            command=lambda: self.move_rel(1000)
        ).grid(row=0,column=4,padx=5,pady=5)

        ttk.Button(
            jog,
            text="HOME",
            command=self.cmd_home
        ).grid(row=1,column=1,pady=5)

        ttk.Button(
            jog,
            text="ZERO",
            command=self.cmd_zero
        ).grid(row=1,column=3,pady=5)

        motion = ttk.LabelFrame(
            self.root,
            text="Positioning"
        )

        motion.pack(
            fill="x",
            padx=10,
            pady=5
        )

        ttk.Label(
            motion,
            text="Target Position"
        ).grid(row=0,column=0)

        self.pos_entry = ttk.Entry(
            motion,
            width=12
        )

        self.pos_entry.insert(
            0,
            "4096"
        )

        self.pos_entry.grid(
            row=0,
            column=1,
            padx=5
        )

        ttk.Button(
            motion,
            text="MOVE",
            command=lambda:
                self.send_frame(
                    CMD_MOVE_ABS,
                    int(self.pos_entry.get())
                )).grid(
            row=0,
            column=2,
            padx=5
        )

        ttk.Label(
            motion,
            text="Relative Move"
        ).grid(row=1,column=0)

        self.rel_entry = ttk.Entry(
            motion,
            width=12
        )

        self.rel_entry.insert(
            0,
            "100"
        )

        self.rel_entry.grid(
            row=1,
            column=1,
            padx=5
        )

        ttk.Button(
            motion,
            text="MOVE REL",
            command=lambda:
                self.send_frame(
                    CMD_MOVE_REL,
                    int(self.rel_entry.get())
                )
        ).grid(
            row=1,
            column=2,
            padx=5
        )

        profile = ttk.LabelFrame(
            self.root,
            text="Motion Profile"
        )

        profile.pack(
            fill="x",
            padx=10,
            pady=5
        )

        self.speed_entry = ttk.Entry(
            profile,
            width=10
        )

        self.speed_entry.insert(
            0,
            "100"
        )

        self.accel_entry = ttk.Entry(
            profile,
            width=10
        )

        self.accel_entry.insert(
            0,
            "50"
        )

        ttk.Label(
            profile,
            text="Speed"
        ).grid(row=0,column=0)

        self.speed_entry.grid(
            row=0,
            column=1
        )

        ttk.Button(
            profile,
            text="SET SPEED",
            command=lambda:
                self.send_frame(
                    CMD_SET_SPEED,
                    int(self.speed_entry.get())
                )
        ).grid(
            row=0,
            column=2,
            padx=5
        )


        ttk.Label(
            profile,
            text="Accel"
        ).grid(row=1,column=0)

        self.accel_entry.grid(
            row=1,
            column=1
        )

        ttk.Button(
            profile,
            text="SET ACCEL",
            command=lambda:
                self.send_frame(
                    CMD_SET_ACCEL,
                    int(self.accel_entry.get())
                )
        ).grid(
            row=1,
            column=2,
            padx=5
        )

        velocity_frame = ttk.LabelFrame(
            self.root,
            text="Velocity Mode"
        )

        velocity_frame.pack(
            fill="x",
            padx=10,
            pady=5
        )

        ttk.Label(
            velocity_frame,
            text="Velocity"
        ).grid(row=0,column=0)

        self.vel_entry = ttk.Entry(
            velocity_frame,
            width=10
        )

        self.vel_entry.insert(
            0,
            "300"
        )

        self.vel_entry.grid(
            row=0,
            column=1
        )

        ttk.Button(
            velocity_frame,
            text="START CW",
            command=self.cmd_vel_cw
        ).grid(
            row=0,
            column=2,
            padx=5
        )

        ttk.Button(
            velocity_frame,
            text="START CCW",
            command=self.cmd_vel_ccw
        ).grid(
            row=0,
            column=3,
            padx=5
        )

        ttk.Button(
            velocity_frame,
            text="STOP",
            command=self.cmd_stop
        ).grid(
            row=0,
            column=4,
            padx=5
        )

        logs_frame = ttk.Frame(self.root)

        logs_frame.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=5
        )

        #======================
        # TELEMETRY
        #======================

        ttk.Button(
            status,
            text="START TELEMETRY",
            command=self.start_telemetry
        ).pack(side="right", padx=10)

        telemetry = ttk.LabelFrame(
            self.root,
            text="Telemetry aNano ID=1"
        )

        telemetry.pack(
            fill="x",
            padx=10,
            pady=5
        )

        # LIVE MPU

        ttk.Label(
            telemetry,
            text="Pitch Live"
        ).grid(row=0, column=0, padx=5, pady=2)

        ttk.Label(
            telemetry,
            textvariable=self.pitch_live_var
        ).grid(row=0, column=1, padx=5)

        ttk.Label(
            telemetry,
            text="Roll Live"
        ).grid(row=0, column=2, padx=5)

        ttk.Label(
            telemetry,
            textvariable=self.roll_live_var
        ).grid(row=0, column=3, padx=5)

        # HIST MPU

        ttk.Label(
            telemetry,
            text="Pitch Peak"
        ).grid(row=1, column=0, padx=5)

        ttk.Label(
            telemetry,
            textvariable=self.pitch_peak_var
        ).grid(row=1, column=1, padx=5)

        ttk.Label(
            telemetry,
            text="Roll Peak"
        ).grid(row=1, column=2, padx=5)

        ttk.Label(
            telemetry,
            textvariable=self.roll_peak_var
        ).grid(row=1, column=3, padx=5)

        # LIVE GYRO

        ttk.Label(
            telemetry,
            text="GX Live"
        ).grid(row=2, column=0, padx=5)

        ttk.Label(
            telemetry,
            textvariable=self.gx_live_var
        ).grid(row=2, column=1, padx=5)

        ttk.Label(
            telemetry,
            text="GY Live"
        ).grid(row=2, column=2, padx=5)

        ttk.Label(
            telemetry,
            textvariable=self.gy_live_var
        ).grid(row=2, column=3, padx=5)

        ttk.Label(
            telemetry,
            text="GZ Live"
        ).grid(row=2, column=4, padx=5)

        ttk.Label(
            telemetry,
            textvariable=self.gz_live_var
        ).grid(row=2, column=5, padx=5)

        # HIST GYRO

        ttk.Label(
            telemetry,
            text="GX Peak"
        ).grid(row=3, column=0, padx=5)

        ttk.Label(
            telemetry,
            textvariable=self.gx_peak_var
        ).grid(row=3, column=1, padx=5)

        ttk.Label(
            telemetry,
            text="GY Peak"
        ).grid(row=3, column=2, padx=5)

        ttk.Label(
            telemetry,
            textvariable=self.gy_peak_var
        ).grid(row=3, column=3, padx=5)

        ttk.Label(
            telemetry,
            text="GZ Peak"
        ).grid(row=3, column=4, padx=5)

        ttk.Label(
            telemetry,
            textvariable=self.gz_peak_var
        ).grid(row=3, column=5, padx=5)

        # PUSH INFO

        ttk.Label(
            telemetry,
            text="Max G"
        ).grid(row=4, column=0, padx=5)

        ttk.Label(
            telemetry,
            textvariable=self.g_peak_var
        ).grid(row=4, column=1, padx=5)

        ttk.Label(
            telemetry,
            text="Push Count"
        ).grid(row=4, column=2, padx=5)

        ttk.Label(
            telemetry,
            textvariable=self.push_count_var
        ).grid(row=4, column=3, padx=5)
  
        # ======================
        # SEND
        # ======================

        tx_frame = ttk.LabelFrame(
            logs_frame,
            text="SEND"
        )

        tx_frame.pack(
            side="left",
            fill="both",
            expand=True,
            padx=5
        )

        self.tx_log = ScrolledText(
            tx_frame,
            height=15
        )

        self.tx_log.pack(
            fill="both",
            expand=True
        )

        # ======================
        # RECV
        # ======================

        rx_frame = ttk.LabelFrame(
            logs_frame,
            text="RECV"
        )

        rx_frame.pack(
            side="left",
            fill="both",
            expand=True,
            padx=5
        )

        self.rx_log = ScrolledText(
            rx_frame,
            height=15
        )

        self.rx_log.pack(
            fill="both",
            expand=True
        )

    # ==========================================
    # LOG
    # ==========================================

    def add_tx(self, text):

        self.tx_log.insert(
            tk.END,
            text + "\n"
        )

        self.tx_log.see(tk.END)


    def add_rx(self, text):

        self.rx_log.insert(
            tk.END,
            text + "\n"
        )

        self.rx_log.see(tk.END)

    

    def rx_worker(self):

        FRAME_SIZE = 14

        while self.ser is not None:

            try:

                frame = self.ser.read(FRAME_SIZE)

                if len(frame) != FRAME_SIZE:
                    continue

                (
                    preamble,
                    board_id,
                    command,
                    motor_id,
                    data1,
                    data2,
                    data3,
                    data4,
                    crc
                ) = struct.unpack(
                    "<BBHBhhhhB",
                    frame
                )

                if preamble != PREAMBLE:
                    continue

                expected_crc = self.calc_crc(
                    preamble,
                    board_id,
                    command,
                    motor_id,
                    data1,
                    data2,
                    data3,
                    data4
                )

                if expected_crc != crc:
                    continue

                # ACK
                self.waiting_reply = False

                if command == CMD_LIVE_MPU:

                    self.pitch_live_var.set(str(data1))
                    self.roll_live_var.set(str(data2))

                elif command == CMD_HIST_MPU:

                    self.pitch_peak_var.set(str(data1))
                    self.roll_peak_var.set(str(data2))

                    self.g_peak_var.set(str(data3))
                    self.push_count_var.set(str(data4))

                elif command == CMD_LIVE_GYRO:

                    self.gx_live_var.set(str(data1))
                    self.gy_live_var.set(str(data2))
                    self.gz_live_var.set(str(data3))

                elif command == CMD_HIST_GYRO:

                    self.gx_peak_var.set(str(data1))
                    self.gy_peak_var.set(str(data2))
                    self.gz_peak_var.set(str(data3))

                elif command == CMD_PUSH_INFO:

                    self.g_peak_var.set(str(data1))
                    self.push_count_var.set(str(data2))

                elif command == CMD_STATUS:

                    self.pos_var.set(str(data1))

                    self.busy_var.set(
                        "BUSY" if data4 else "READY"
                    )

                self.root.after(
                    0,
                    lambda cmd=command,
                        bid=board_id,
                        mid=motor_id,
                        d1=data1,
                        d2=data2,
                        d3=data3,
                        d4=data4:
                        self.add_rx(
                            f"RX "
                            f"cmd=0x{cmd:04X} "
                            f"id={bid} "
                            f"motor={mid} "
                            f"d1={d1} "
                            f"d2={d2} "
                            f"d3={d3} "
                            f"d4={d4}"
                        )
                )

            except Exception as e:

                self.root.after(
                    0,
                    lambda err=str(e):
                        self.add_rx(
                            f"RX ERROR: {err}"
                        )
                )

                break
    # ==========================================
    # CRC
    # ==========================================

    def calc_crc(
        self,
        preamble,
        device_id,
        command,
        motor_id,
        data1,
        data2,
        data3,
        data4
    ):

        crc = 0

        crc ^= preamble
        crc ^= device_id

        crc ^= (command >> 8) & 0xFF
        crc ^= command & 0xFF

        crc ^= motor_id

        crc ^= (data1 >> 8) & 0xFF
        crc ^= data1 & 0xFF

        crc ^= (data2 >> 8) & 0xFF
        crc ^= data2 & 0xFF

        crc ^= (data3 >> 8) & 0xFF
        crc ^= data3 & 0xFF

        crc ^= (data4 >> 8) & 0xFF
        crc ^= data4 & 0xFF

        return crc & 0xFF

    # ==========================================
    # UART
    # ==========================================

    def connect(self):

        if self.ser is not None:

            self.add_rx("Already connected")
            return

        try:

            self.ser = serial.Serial(
            self.com_var.get(),
            115200,
            timeout=1
            )

            self.ser.reset_input_buffer()
            self.ser.reset_output_buffer()

            self.status_label.config(
                text="● ONLINE",
                fg="green"
            )

            self.add_rx(
                f"Connected {self.com_var.get()}"
            )

            threading.Thread(
                target=self.rx_worker,
                daemon=True
            ).start()


        except Exception as e:

            self.add_rx(
                f"ERROR: {e}"
            )
        

    def disconnect(self):

        if self.ser is None:
            return

        try:

            self.ser.close()

        except:
            pass

        self.ser = None

        self.status_label.config(
            text="● OFFLINE",
            fg="red"
        )

        self.add_rx(
            "Disconnected"
        )

    def quit_app(self):

        self.disconnect()
        self.root.destroy()

    # ==========================================
    # SEND
    # ==========================================

    def send_frame(
        self,
        command,
        data1=0
    ):
        if self.ser is None:

            self.add_tx(
                "Not connected"
            )

            return

        if self.waiting_reply:
            self.add_tx(
                "WAITING FOR ACK"
            )
            return

        board_id = self.board_var.get()
        motor_id = self.motor_var.get()

        crc = self.calc_crc(
            PREAMBLE,
            board_id,
            command,
            motor_id,
            data1,
            0,
            0,
            0
        )

        frame = struct.pack(
            "<BBHBhhhhB",
            PREAMBLE,
            board_id,
            command,
            motor_id,
            data1,
            0,
            0,
            0,
            crc
        )

        self.ser.write(frame)

        self.waiting_reply = True

        self.add_tx(
                f"TX cmd=0x{command:04X} "
                f"board={board_id} "
                f"motor={motor_id} "
                f"data={data1}"
            )

    # ==========================================
    # COMMANDS
    # ==========================================

    def cmd_home(self):

        self.send_frame(
            CMD_HOMING
        )

    def cmd_stop(self):

        self.send_frame(
            CMD_STOP_MOTOR
        )

    def cmd_zero(self):

        self.send_frame(
            CMD_MOVE_ABS,
            0
        )

    def move_rel(self, value):

        self.send_frame(
            CMD_MOVE_REL,
            value
        )

    def cmd_vel_cw(self):

        self.send_frame(
            CMD_MOVE_VELOCITY,
            int(
                self.vel_entry.get()
            )
        )

    def cmd_vel_ccw(self):

        self.send_frame(
            CMD_MOVE_VELOCITY,
            -int(
                self.vel_entry.get()
            )
        )

    # ==========================================
    # TELEMETRY
    # ==========================================
    def start_telemetry(self):

        if self.telemetry_enabled:
            return

        self.telemetry_enabled = True

        threading.Thread(
            target=self.telemetry_worker,
            daemon=True
        ).start()

    def telemetry_worker(self):

        telemetry_cmds = [
            CMD_LIVE_MPU,
            CMD_HIST_MPU,
            CMD_LIVE_GYRO,
            CMD_HIST_GYRO,
            CMD_PUSH_INFO
        ]

        idx = 0

        while self.telemetry_enabled:

            if not self.waiting_reply:

                old_board = self.board_var.get()

                self.board_var.set(1)

                self.send_frame(
                    telemetry_cmds[idx]
                )

                self.board_var.set(old_board)

                idx += 1

                if idx >= len(telemetry_cmds):
                    idx = 0

            threading.Event().wait(0.4)


root = tk.Tk()

app = UARTGui(root)

root.mainloop()