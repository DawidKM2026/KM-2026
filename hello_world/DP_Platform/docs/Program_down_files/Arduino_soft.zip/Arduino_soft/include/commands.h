#ifndef COMMANDS_H
#define COMMANDS_H

// =====================================================
// COMMAND MAP
// =====================================================
//
// Magistrala UART Master-Slave
//
// Master:
//      ESP32
//
// Slave:
//      Arduino Nano ID=1..5
//
// Adresacja:
//
//      ID = 0
//          Broadcast
//          Wykonaj polecenie na wszystkich modułach
//          Bez odpowiedzi UART
//
//      ID = 1..5
//          Polecenie dla konkretnego modułu
//          Moduł wykonuje operację
//          Moduł odsyła odpowiedź
//
// =====================================================
// SYSTEM COMMANDS
// =====================================================

//
// Sprawdzenie obecności modułu
//
// Odpowiedź:
//      CMD_PING
//
#define CMD_PING        0x0001

//
// Podstawowy status urządzenia
//
// data1 = pozycja silnika
// data2 = liczba push
// data3 = myID
//
#define CMD_STATUS      0x0002

// =====================================================
// MPU6500 - LIVE DATA
// =====================================================

//
// Aktualne dane MPU6500
//
// data1 = Pitch
// data2 = Roll
// data3 = Gyro X
// data4 = Gyro Y
//
#define CMD_LIVE_MPU    0x0004

//
// Aktualne dane żyroskopu
//
// data1 = Gyro X
// data2 = Gyro Y
// data3 = Gyro Z
//
#define CMD_LIVE_GYRO   0x0010

// =====================================================
// MPU6500 - HISTORY
// =====================================================

//
// Historia ruchu od ostatniego resetu
//
// data1 = Max Pitch
// data2 = Max Roll
// data3 = Max DynamicG
// data4 = Push Count
//
#define CMD_HIST_MPU    0x0008

//
// Historia żyroskopu
//
// data1 = Max Gyro X
// data2 = Max Gyro Y
// data3 = Max Gyro Z
//
#define CMD_HIST_GYRO   0x0020

//
// Informacje o wykrytych pchnięciach
//
// data1 = Max DynamicG
// data2 = Push Count
//
#define CMD_PUSH_INFO   0x0040

//
// Reset wszystkich statystyk MPU6500
//
// Zerowane:
//
//      pitchPeak
//      rollPeak
//
//      gxPeak
//      gyPeak
//      gzPeak
//
//      maxDynamicG
//
//      pushCount
//
#define CMD_RESET_STAT  0x0080

// =====================================================
// STEPPER CONTROL
// =====================================================

//
// Procedura homingu
//
// Broadcast:
//      wszystkie osie wykonują homing
//
// Unicast:
//      tylko wskazany moduł
//
#define CMD_HOMING      0x0100

//
// Ruch absolutny
//
// data1 = pozycja docelowa
//
#define CMD_MOVE_ABS    0x0200

//
// Ruch względny
//
// data1 = ilość kroków
//
// +1000  -> do przodu
// -1000  -> do tyłu
//
#define CMD_MOVE_REL    0x0400

//
// Natychmiastowe zatrzymanie silnika
//
#define CMD_STOP_MOTOR  0x0800

//
// Ustawienie prędkości maksymalnej
//
// data1 = kroki/s
//
#define CMD_SET_SPEED   0x1000

//
// Ustawienie przyspieszenia
//
// data1 = kroki/s²
//
#define CMD_SET_ACCEL   0x2000

//
// Ruch ciągły ze zdefiniowaną prędkością.
//
// data1 > 0 -> kierunek dodatni
// data1 < 0 -> kierunek ujemny
//
// Jednostka:
//
// kroki/s
//
#define CMD_MOVE_VELOCITY 0x4000

#endif