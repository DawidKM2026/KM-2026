#ifndef STEPPER_CTRL_H
#define STEPPER_CTRL_H

#include <Arduino.h>
#include <AccelStepper.h>

// =====================================================
// LIMITS
// =====================================================

#define MAX_STEPPER_SPEED  2000
#define MIN_STEPPER_SPEED -2000

#define MAX_MOTORS 8

#define STEPS_PER_REV 4096
// =====================================================
// MOTORS
// =====================================================

extern AccelStepper stepper1;

// =====================================================
// INIT / UPDATE
// =====================================================

void initStepper(uint8_t myID);

void updateStepper();

// =====================================================
// POSITION CONTROL
// =====================================================

void homeStepper(
    uint8_t motorID);

void moveStepper(
    uint8_t motorID,
    long position);

void moveStepperRelative(
    uint8_t motorID,
    long steps);

// =====================================================
// MOTION CONTROL
// =====================================================

void stopStepper(
    uint8_t motorID);

void setStepperVelocity(
    uint8_t motorID,
    float velocity);

void setStepperSpeed(
    uint8_t motorID,
    float speed);

void setStepperAcceleration(
    uint8_t motorID,
    float accel);

// =====================================================
// STATUS
// =====================================================

long getStepperPosition(
    uint8_t motorID);

bool isStepperBusy(
    uint8_t motorID);

// =====================================================
// POSITION NORMALIZATION
// =====================================================

void normalizeStepperPosition(
    uint8_t motorID);

#endif