#ifndef BOARD_ID_H
#define BOARD_ID_H

#include <Arduino.h>

uint8_t readBoardID();

uint8_t getMotorCount(uint8_t boardID);

#endif