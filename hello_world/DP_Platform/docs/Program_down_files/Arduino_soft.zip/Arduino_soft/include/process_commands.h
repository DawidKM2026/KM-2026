#ifndef PROCESS_COMMANDS_H
#define PROCESS_COMMANDS_H

#include <Arduino.h>

#include "uart_protocol.h"



// =====================================================
// UART COMMAND PROCESSOR
// =====================================================

void processFrame(
    Frame& rx,
    uint8_t myID);

#endif