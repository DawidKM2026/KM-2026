#ifndef UART_PROTOCOL_H
#define UART_PROTOCOL_H

#include <Arduino.h>

#define PREAMBLE 0xAA



struct Frame
{
    uint8_t preamble;

    // 0 = broadcast
    // 1..5 = adres modułu
    uint8_t id;

    // komenda protokołu
    uint16_t command;

    // 0 = silnik domyślny
    // 1..255 = kolejne silniki
    uint8_t motorID;

    int16_t data1;
    int16_t data2;
    int16_t data3;
    int16_t data4;

    uint8_t crc;
};

uint8_t calcCRC(const Frame& f);

void sendFrame(
    uint8_t id,
    uint16_t command,
    uint8_t motorID,

    int16_t data1,
    int16_t data2,
    int16_t data3,
    int16_t data4);

bool receiveFrame(Frame& rx);

#endif