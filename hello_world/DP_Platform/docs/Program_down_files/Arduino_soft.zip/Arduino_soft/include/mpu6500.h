#ifndef MPU6500_H
#define MPU6500_H

#include <Arduino.h>

extern float pitchCurrent;
extern float rollCurrent;

extern float gxCurrent;
extern float gyCurrent;
extern float gzCurrent;

extern float pitchPeak;
extern float rollPeak;

extern float gxPeak;
extern float gyPeak;
extern float gzPeak;

extern float maxDynamicG;

extern uint16_t pushCount;

void initMPU6500();
void readMPU6500();

#endif