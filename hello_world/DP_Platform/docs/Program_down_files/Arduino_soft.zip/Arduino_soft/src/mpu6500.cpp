#include "mpu6500.h"

#include <SPI.h>

// =====================================================
// GLOBAL DATA
// =====================================================

float pitchCurrent = 0.0f;
float rollCurrent  = 0.0f;

float pitchPeak = 0.0f;
float rollPeak  = 0.0f;

float gxCurrent = 0.0f;
float gyCurrent = 0.0f;
float gzCurrent = 0.0f;

float gxPeak = 0.0f;
float gyPeak = 0.0f;
float gzPeak = 0.0f;

float maxDynamicG = 0.0f;

uint16_t pushCount = 0;

// =====================================================
// MPU6500
// =====================================================

const byte CS_PIN = 10;

void writeRegister(
    uint8_t reg,
    uint8_t value)
{
    digitalWrite(CS_PIN, LOW);

    SPI.transfer(reg);
    SPI.transfer(value);

    digitalWrite(CS_PIN, HIGH);
}

uint8_t readRegister(
    uint8_t reg)
{
    digitalWrite(CS_PIN, LOW);

    SPI.transfer(reg | 0x80);

    uint8_t value =
        SPI.transfer(0x00);

    digitalWrite(CS_PIN, HIGH);

    return value;
}

void readRegisters(
    uint8_t reg,
    uint8_t* buffer,
    uint8_t count)
{
    digitalWrite(CS_PIN, LOW);

    SPI.transfer(reg | 0x80);

    for(uint8_t i = 0; i < count; i++)
    {
        buffer[i] =
            SPI.transfer(0x00);
    }

    digitalWrite(CS_PIN, HIGH);
}

void initMPU6500()
{
    pinMode(CS_PIN, OUTPUT);

    digitalWrite(
        CS_PIN,
        HIGH);

    SPI.begin();

    SPI.beginTransaction(
        SPISettings(
            1000000,
            MSBFIRST,
            SPI_MODE0));

    writeRegister(
        0x6B,
        0x00);

    delay(100);

    uint8_t whoami =
        readRegister(0x75);

    Serial.print("WHO_AM_I = 0x");
    Serial.println(
        whoami,
        HEX);

    Serial.println(
        "MPU6500 started");
}

void readMPU6500()
{
    // =========================
    // ACCELEROMETER
    // =========================

    uint8_t accelData[6];

    readRegisters(
        0x3B,
        accelData,
        6);

    int16_t ax =
        (accelData[0] << 8) |
        accelData[1];

    int16_t ay =
        (accelData[2] << 8) |
        accelData[3];

    int16_t az =
        (accelData[4] << 8) |
        accelData[5];

    float axg =
        ax / 16384.0f;

    float ayg =
        ay / 16384.0f;

    float azg =
        az / 16384.0f;

    pitchCurrent =
        atan2(
            axg,
            sqrt(
                ayg * ayg +
                azg * azg))
        * 180.0f / PI;

    rollCurrent =
        atan2(
            ayg,
            sqrt(
                axg * axg +
                azg * azg))
        * 180.0f / PI;

    float totalG =
        sqrt(
            axg * axg +
            ayg * ayg +
            azg * azg);

    float dynamicG =
        abs(totalG - 1.0f);

    if(abs(pitchCurrent) >
       abs(pitchPeak))
    {
        pitchPeak =
            pitchCurrent;
    }

    if(abs(rollCurrent) >
       abs(rollPeak))
    {
        rollPeak =
            rollCurrent;
    }

    if(dynamicG >
       maxDynamicG)
    {
        maxDynamicG =
            dynamicG;
    }

    if(dynamicG > 0.10f)
    {
        pushCount++;
    }

    // =========================
    // GYROSCOPE
    // =========================

    uint8_t gyroData[6];

    readRegisters(
        0x43,
        gyroData,
        6);

    int16_t gx =
        (gyroData[0] << 8) |
        gyroData[1];

    int16_t gy =
        (gyroData[2] << 8) |
        gyroData[3];

    int16_t gz =
        (gyroData[4] << 8) |
        gyroData[5];

    gxCurrent =
        gx / 131.0f;

    gyCurrent =
        gy / 131.0f;

    gzCurrent =
        gz / 131.0f;

    if(abs(gxCurrent) > gxPeak)
    {
        gxPeak =
            abs(gxCurrent);
    }

    if(abs(gyCurrent) > gyPeak)
    {
        gyPeak =
            abs(gyCurrent);
    }

    if(abs(gzCurrent) > gzPeak)
    {
        gzPeak =
            abs(gzCurrent);
    }
}