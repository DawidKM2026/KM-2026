#include "stepper_ctrl.h"

// =====================================================
// MOTORS
// =====================================================

AccelStepper stepper1(
    AccelStepper::HALF4WIRE,
    D2,
    D4,
    D3,
    A0
);

AccelStepper stepper2(
    AccelStepper::HALF4WIRE,
    D6,
    D8,
    D7,
    D9
);

AccelStepper stepper3(
    AccelStepper::HALF4WIRE,
    A2,
    A3,
    A4,
    A5
);

AccelStepper stepper4(
    AccelStepper::HALF4WIRE,
    D10,
    D11,
    D12,
    D13
);

// AccelStepper stepperX(...);

// =====================================================
// STORAGE
// =====================================================

AccelStepper* motors[MAX_MOTORS];

static bool velocityMode[MAX_MOTORS];

// =====================================================
// INTERNAL
// =====================================================

static AccelStepper* getMotor(
    uint8_t motorID)
{
    if(motorID == 0)
    {
        return nullptr;
    }

    if(motorID > MAX_MOTORS)
    {
        return nullptr;
    }

    return motors[motorID - 1];
}

// =====================================================
// INIT
// =====================================================

void initStepper(uint8_t myID)
{
    // Reset tablic

    for(uint8_t i = 0; i < MAX_MOTORS; i++)
    {
        motors[i] = nullptr;
        velocityMode[i] = false;
    }

    // Rejestracja silnikow

    motors[0] = &stepper1;
    motors[1] = &stepper2;
    motors[2] = &stepper3;

    if(myID != 1)
    {
        motors[3] = &stepper4;
    }

    // =====================================
    // Motor 1
    // D2 D3 D4 A0
    // =====================================

    pinMode(D2, OUTPUT);
    pinMode(D3, OUTPUT);
    pinMode(D4, OUTPUT);
    pinMode(A0, OUTPUT);

    digitalWrite(D2, LOW);
    digitalWrite(D3, LOW);
    digitalWrite(D4, LOW);
    digitalWrite(A0, LOW);

    // =====================================
    // Motor 2
    // D6 D7 D8 D9
    // =====================================

    pinMode(D6, OUTPUT);
    pinMode(D7, OUTPUT);
    pinMode(D8, OUTPUT);
    pinMode(D9, OUTPUT);

    digitalWrite(D6, LOW);
    digitalWrite(D7, LOW);
    digitalWrite(D8, LOW);
    digitalWrite(D9, LOW);

    // =====================================
    // Motor 3
    // A2 A3 A4 A5
    // =====================================

    pinMode(A2, OUTPUT);
    pinMode(A3, OUTPUT);
    pinMode(A4, OUTPUT);
    pinMode(A5, OUTPUT);

    digitalWrite(A2, LOW);
    digitalWrite(A3, LOW);
    digitalWrite(A4, LOW);
    digitalWrite(A5, LOW);

    // =====================================
    // Motor 4
    // D10 D11 D12 D13
    // tylko gdy nie ma MPU6500
    // =====================================

    if(myID != 1)
    {
        pinMode(D10, OUTPUT);
        pinMode(D11, OUTPUT);
        pinMode(D12, OUTPUT);
        pinMode(D13, OUTPUT);

        digitalWrite(D10, LOW);
        digitalWrite(D11, LOW);
        digitalWrite(D12, LOW);
        digitalWrite(D13, LOW);
    }

    // =====================================
    // Parametry silnikow
    // =====================================

    uint8_t motorCount =
        (myID == 1) ? 3 : 4;

    for(uint8_t i = 0; i < motorCount; i++)
    {
        motors[i]->setMaxSpeed(800);
        motors[i]->setAcceleration(400);
    }
}

// =====================================================
// UPDATE
// =====================================================

void updateStepper()
{
    for(uint8_t i = 0; i < MAX_MOTORS; i++)
    {
        if(motors[i] == nullptr)
        {
            continue;
        }

        if(velocityMode[i])
        {
            motors[i]->runSpeed();
        }
        else
        {
            motors[i]->run();
        }
    }
}

// =====================================================
// HOMING
// =====================================================

void homeStepper(
    uint8_t motorID)
{
    if(motorID == 0)
    {
        for(uint8_t i = 1; i <= MAX_MOTORS; i++)
        {
            homeStepper(i);
        }

        return;
    }

    AccelStepper* motor =
        getMotor(motorID);

    if(motor == nullptr)
    {
        return;
    }

    velocityMode[motorID - 1] = false;

    motor->moveTo(0);
}

// =====================================================
// ABSOLUTE MOVE
// =====================================================

void moveStepper(
    uint8_t motorID,
    long position)
{
    if(motorID == 0)
    {
        for(uint8_t i = 1; i <= MAX_MOTORS; i++)
        {
            moveStepper(
                i,
                position);
        }

        return;
    }

    AccelStepper* motor =
        getMotor(motorID);

    if(motor == nullptr)
    {
        return;
    }

    velocityMode[motorID - 1] = false;

    motor->moveTo(position);
}

// =====================================================
// RELATIVE MOVE
// =====================================================

void moveStepperRelative(
    uint8_t motorID,
    long steps)
{
    if(motorID == 0)
    {
        for(uint8_t i = 1; i <= MAX_MOTORS; i++)
        {
            moveStepperRelative(
                i,
                steps);
        }

        return;
    }

    AccelStepper* motor =
        getMotor(motorID);

    if(motor == nullptr)
    {
        return;
    }

    velocityMode[motorID - 1] = false;

    motor->move(steps);
}

// =====================================================
// STOP
// =====================================================

void stopStepper(
    uint8_t motorID)
{
    if(motorID == 0)
    {
        for(uint8_t i = 1; i <= MAX_MOTORS; i++)
        {
            stopStepper(i);
        }

        return;
    }

    AccelStepper* motor =
        getMotor(motorID);

    if(motor == nullptr)
    {
        return;
    }

    velocityMode[motorID - 1] = false;

    motor->stop();
}

// =====================================================
// SPEED
// =====================================================

void setStepperSpeed(
    uint8_t motorID,
    float speed)
{
    if(motorID == 0)
    {
        for(uint8_t i = 1; i <= MAX_MOTORS; i++)
        {
            setStepperSpeed(
                i,
                speed);
        }

        return;
    }

    AccelStepper* motor =
        getMotor(motorID);

    if(motor == nullptr)
    {
        return;
    }

    motor->setMaxSpeed(speed);
}

// =====================================================
// ACCELERATION
// =====================================================

void setStepperAcceleration(
    uint8_t motorID,
    float accel)
{
    if(motorID == 0)
    {
        for(uint8_t i = 1; i <= MAX_MOTORS; i++)
        {
            setStepperAcceleration(
                i,
                accel);
        }

        return;
    }

    AccelStepper* motor =
        getMotor(motorID);

    if(motor == nullptr)
    {
        return;
    }

    motor->setAcceleration(accel);
}

// =====================================================
// POSITION
// =====================================================

long getStepperPosition(
    uint8_t motorID)
{
    AccelStepper* motor =
        getMotor(motorID);

    if(motor == nullptr)
    {
        return 0;
    }

    return motor->currentPosition();
}

// =====================================================
// BUSY
// =====================================================

bool isStepperBusy(
    uint8_t motorID)
{
    AccelStepper* motor =
        getMotor(motorID);

    if(motor == nullptr)
    {
        return false;
    }

    return motor->distanceToGo() != 0;
}

// =====================================================
// VELOCITY MODE
// =====================================================

void setStepperVelocity(
    uint8_t motorID,
    float velocity)
{
    if(motorID == 0)
    {
        for(uint8_t i = 1; i <= MAX_MOTORS; i++)
        {
            setStepperVelocity(
                i,
                velocity);
        }

        return;
    }

    AccelStepper* motor =
        getMotor(motorID);

    if(motor == nullptr)
    {
        return;
    }

    velocityMode[motorID - 1] = true;

    motor->setSpeed(
        velocity);
}

void normalizeStepperPosition(
    uint8_t motorID)
{
    AccelStepper* motor =
        getMotor(motorID);

    if(motor == nullptr)
    {
        return;
    }

    long pos =
        motor->currentPosition();

    pos %= STEPS_PER_REV;

    if(pos < 0)
    {
        pos += STEPS_PER_REV;
    }

    motor->setCurrentPosition(pos);
}
