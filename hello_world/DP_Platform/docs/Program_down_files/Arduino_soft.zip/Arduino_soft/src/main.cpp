/*
MIT License
 
Copyright (c) 2019 ElectronicCats
 
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
 
The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
 
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/


#include <Arduino.h>
#include <Wire.h>

#include "board_id.h"
#include "uart_protocol.h"
#include "mpu6500.h"
#include "stepper_ctrl.h"
#include "commands.h"
#include "process_commands.h"

// =====================================================
// GLOBAL
// =====================================================

uint8_t myID = 0;

// =====================================================
// SETUP
// =====================================================

void setup()
{
    Serial.begin(115200);

    Serial.println("=== BOOT ===");

    // -----------------------------------------
    // I2C
    // -----------------------------------------

    Wire.begin();

    // -----------------------------------------
    // Odczyt ID płytki
    // -----------------------------------------

    myID = readBoardID();

    Serial.print("ADC = ");
    Serial.println(analogRead(A0));

    Serial.print("ID = ");
    Serial.println(myID);

    // -----------------------------------------
    // Silnik krokowy
    // -----------------------------------------

    initStepper(myID);

    // -----------------------------------------
    // MPU6500 tylko dla ID=1
    // -----------------------------------------

    if (myID == 1)
    {
        initMPU6500();
    }
}

// =====================================================
// LOOP
// =====================================================

void loop()
{
    // -----------------------------------------
    // Aktualizacja silnika
    // -----------------------------------------

    updateStepper();

    // -----------------------------------------
    // Aktualizacja MPU6500
    // tylko dla modułu ID=1
    // -----------------------------------------

    if (myID == 1)
    {
        static uint32_t lastMPU = 0;

        if (millis() - lastMPU >= 10)
        {
            lastMPU = millis();
            readMPU6500();
        }
    }

    // -----------------------------------------
    // Odbiór UART
    // -----------------------------------------

    Frame rx;

    if (receiveFrame(rx))
    {
        // ramka przeznaczona dla mnie lub broadcast

        if (rx.id == myID || rx.id == 0)
        {
            processFrame(rx, myID);
        }
    }
}