#include "uart_protocol.h"

uint8_t calcCRC(const Frame& f)
{
    uint8_t crc = 0;

    crc ^= f.preamble;
    crc ^= f.id;

    crc ^= (uint8_t)(f.command >> 8);
    crc ^= (uint8_t)(f.command);

    crc ^= f.motorID;

    crc ^= (uint8_t)(f.data1 >> 8);
    crc ^= (uint8_t)(f.data1);

    crc ^= (uint8_t)(f.data2 >> 8);
    crc ^= (uint8_t)(f.data2);

    crc ^= (uint8_t)(f.data3 >> 8);
    crc ^= (uint8_t)(f.data3);

    crc ^= (uint8_t)(f.data4 >> 8);
    crc ^= (uint8_t)(f.data4);

    return crc;
}

void sendFrame(
    uint8_t id,
    uint16_t command,
    uint8_t motorID,

    int16_t data1,
    int16_t data2,
    int16_t data3,
    int16_t data4)
{
    Frame tx;

    tx.preamble = PREAMBLE;

    tx.id      = id;
    tx.command = command;
    tx.motorID = motorID;

    tx.data1 = data1;
    tx.data2 = data2;
    tx.data3 = data3;
    tx.data4 = data4;

    tx.crc = calcCRC(tx);

    Serial.write(
        (uint8_t*)&tx,
        sizeof(Frame));
}

bool receiveFrame(Frame& rx)
{
   if(Serial.available() < (int)sizeof(Frame))
    {
        return false;
    }

    Serial.readBytes(
        (char*)&rx,
        sizeof(Frame));

    if(rx.preamble != PREAMBLE)
    {
        return false;
    }

    if(rx.crc != calcCRC(rx))
    {
        return false;
    }

    return true;
}