#include "board_id.h"

uint8_t readBoardID()
{
    analogReadResolution(12);

    pinMode(D4, OUTPUT);
    digitalWrite(D4, HIGH);

    pinMode(A0, INPUT);

    delay(1000);

    uint32_t sum = 0;

    for(int i = 0; i < 32; i++)
    {
        sum += analogRead(A0);
        delayMicroseconds(100);
    }

    uint16_t adc = sum / 32;
    
    Serial.print("ADC = ");
    Serial.println(adc);

    if(adc > 391)      return 1;
    else if(adc > 217) return 2;
    else if(adc > 90) return 3;
    else if(adc > 40)  return 4;
    else               return 5;

}

uint8_t getMotorCount(uint8_t boardID)
{
    switch(boardID)
    {
        case 1:
            return 3;   // płytka z MPU

        default:
            return 4;   // pozostałe płytki
    }
}