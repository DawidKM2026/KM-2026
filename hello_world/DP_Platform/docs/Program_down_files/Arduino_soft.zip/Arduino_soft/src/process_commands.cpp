#include "process_commands.h"

#include "commands.h"
#include "uart_protocol.h"
#include "mpu6500.h"
#include "stepper_ctrl.h"

// =====================================================
// SYSTEM
// =====================================================

static void handlePing(
    uint8_t myID,
    bool replyAllowed)
{
    if(replyAllowed)
    {
        sendFrame(
            myID,
            CMD_PING,
            0,

            0,
            0,
            0,
            0);
    }
}

static void handleStatus(
    Frame& rx,
    uint8_t myID,
    bool replyAllowed)
{
    if(replyAllowed)
    {
        sendFrame(
            myID,
            CMD_STATUS,
            rx.motorID,

            (int16_t)getStepperPosition(rx.motorID),
            (int16_t)pushCount,

            (int16_t)myID,
            (int16_t)isStepperBusy(rx.motorID));
    }
}

// =====================================================
// MPU6500
// =====================================================

static void handleLiveMPU(
    uint8_t myID,
    bool replyAllowed)
{
    if(myID != 1)
    {
        return;
    }

    if(replyAllowed)
    {
        sendFrame(
            myID,
            CMD_LIVE_MPU,
            0,

            (int16_t)pitchCurrent,
            (int16_t)rollCurrent,

            0,
            0);
    }
}

static void handleLiveGyro(
    uint8_t myID,
    bool replyAllowed)
{
    if(myID != 1)
    {
        return;
    }

    if(replyAllowed)
    {
        sendFrame(
            myID,
            CMD_LIVE_GYRO,
            0,

            (int16_t)gxCurrent,
            (int16_t)gyCurrent,

            (int16_t)gzCurrent,
            0);
    }
}

static void handleHistMPU(
    uint8_t myID,
    bool replyAllowed)
{
    if(myID != 1)
    {
        return;
    }

    if(replyAllowed)
    {
        sendFrame(
            myID,
            CMD_HIST_MPU,
            0,

            (int16_t)pitchPeak,
            (int16_t)rollPeak,

            (int16_t)maxDynamicG,
            (int16_t)pushCount);
    }
}

static void handleHistGyro(
    uint8_t myID,
    bool replyAllowed)
{
    if(myID != 1)
    {
        return;
    }

    if(replyAllowed)
    {
        sendFrame(
            myID,
            CMD_HIST_GYRO,
            0,

            (int16_t)gxPeak,
            (int16_t)gyPeak,

            (int16_t)gzPeak,
            0);
    }
}

static void handlePushInfo(
    uint8_t myID,
    bool replyAllowed)
{
    if(myID != 1)
    {
        return;
    }

    if(replyAllowed)
    {
        sendFrame(
            myID,
            CMD_PUSH_INFO,
            0,

            (int16_t)maxDynamicG,
            (int16_t)pushCount,

            0,
            0);
    }
}

static void handleResetStat(
    uint8_t myID,
    bool replyAllowed)
{
    if(myID != 1)
    {
        return;
    }

    pitchPeak = 0.0f;
    rollPeak  = 0.0f;

    gxPeak = 0.0f;
    gyPeak = 0.0f;
    gzPeak = 0.0f;

    maxDynamicG = 0.0f;

    pushCount = 0;

    if(replyAllowed)
    {
        sendFrame(
            myID,
            CMD_RESET_STAT,
            0,

            1,
            0,
            0,
            0);
    }
}

// =====================================================
// STEPPER
// =====================================================

static void handleHoming(
    Frame& rx,
    uint8_t myID,
    bool replyAllowed)
{
    homeStepper(
        rx.motorID);

    if(replyAllowed)
    {
        sendFrame(
            myID,
            CMD_HOMING,
            rx.motorID,

            0,
            0,
            0,
            0);
    }
}

static void handleMoveAbs(
    Frame& rx,
    uint8_t myID,
    bool replyAllowed)
{
    moveStepper(
        rx.motorID,
        rx.data1);

    if(replyAllowed)
    {
        sendFrame(
            myID,
            CMD_MOVE_ABS,
            rx.motorID,

            rx.data1,
            0,
            0,
            0);
    }
}

static void handleMoveRel(
    Frame& rx,
    uint8_t myID,
    bool replyAllowed)
{
    moveStepperRelative(
        rx.motorID,
        rx.data1);

    if(replyAllowed)
    {
        sendFrame(
            myID,
            CMD_MOVE_REL,
            rx.motorID,

            rx.data1,
            0,
            0,
            0);
    }
}

static void handleMoveVelocity(
    Frame& rx,
    uint8_t myID,
    bool replyAllowed)
{
    int16_t velocity =
        constrain(
            rx.data1,
            MIN_STEPPER_SPEED,
            MAX_STEPPER_SPEED);

    setStepperVelocity(
        rx.motorID,
        velocity);

    if(replyAllowed)
    {
        sendFrame(
            myID,
            CMD_MOVE_VELOCITY,
            rx.motorID,

            velocity,
            0,
            0,
            0);
    }
}

static void handleStopMotor(
    Frame& rx,
    uint8_t myID,
    bool replyAllowed)
{
    stopStepper(
        rx.motorID);

    if(replyAllowed)
    {
        sendFrame(
            myID,
            CMD_STOP_MOTOR,
            rx.motorID,

            0,
            0,
            0,
            0);
    }
}

static void handleSetSpeed(
    Frame& rx,
    uint8_t myID,
    bool replyAllowed)
{
    setStepperSpeed(
        rx.motorID,
        rx.data1);

    if(replyAllowed)
    {
        sendFrame(
            myID,
            CMD_SET_SPEED,
            rx.motorID,

            rx.data1,
            0,
            0,
            0);
    }
}

static void handleSetAccel(
    Frame& rx,
    uint8_t myID,
    bool replyAllowed)
{
    setStepperAcceleration(
        rx.motorID,
        rx.data1);

    if(replyAllowed)
    {
        sendFrame(
            myID,
            CMD_SET_ACCEL,
            rx.motorID,

            rx.data1,
            0,
            0,
            0);
    }
}

// =====================================================
// FRAME PROCESSING
// =====================================================

void processFrame(
    Frame& rx,
    uint8_t myID)
{
  
    bool broadcast =
    (
        rx.id == 0
    );

    bool replyAllowed =
    (
        !broadcast
    );

    switch(rx.command)
    {
        case CMD_PING:
            handlePing(myID, replyAllowed);
            break;

        case CMD_STATUS:
            handleStatus(rx, myID, replyAllowed);
            break;

        case CMD_LIVE_MPU:
            handleLiveMPU(myID, replyAllowed);
            break;

        case CMD_LIVE_GYRO:
            handleLiveGyro(myID, replyAllowed);
            break;

        case CMD_HIST_MPU:
            handleHistMPU(myID, replyAllowed);
            break;

        case CMD_HIST_GYRO:
            handleHistGyro(myID, replyAllowed);
            break;

        case CMD_PUSH_INFO:
            handlePushInfo(myID, replyAllowed);
            break;

        case CMD_RESET_STAT:
            handleResetStat(myID, replyAllowed);
            break;

        case CMD_HOMING:
            handleHoming(rx, myID, replyAllowed);
            break;

        case CMD_MOVE_ABS:
            handleMoveAbs(rx, myID, replyAllowed);
            break;

        case CMD_MOVE_REL:
            handleMoveRel(rx, myID, replyAllowed);
            break;

        case CMD_MOVE_VELOCITY:
            handleMoveVelocity(rx, myID, replyAllowed);
            break;

        case CMD_STOP_MOTOR:
            handleStopMotor(rx, myID, replyAllowed);
            break;

        case CMD_SET_SPEED:
            handleSetSpeed(rx, myID, replyAllowed);
            break;

        case CMD_SET_ACCEL:
            handleSetAccel(rx, myID, replyAllowed);
            break;

        default:
            break;
    }
}